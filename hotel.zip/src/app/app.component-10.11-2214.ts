import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';
import * as data from '../assets/reservations.json';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})


export class AppComponent {
  title = 'hero';
  products:any;

  constructor(private http: HttpClient) {
    this.http.get('../assets/reservations.json').subscribe(data =>{
      console.log('data....',data);
      this.products = data;
    })
  }

}
