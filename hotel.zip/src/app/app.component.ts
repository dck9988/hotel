import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';
import studentsData from './students.json';
import reservationData from './reservations.json';

interface Student {
  id: Number;
  name: String;
  email: String;
  gender: String;
}

interface Reservation {
  stay:{
    arrivalDate: String;
    departureDate: String;
  }
  firstName: String;
  lastName: String;
  email: String;
  phone: String;

}

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: [ './app.component.css' ]
})

export class AppComponent {
  title = 'Angular JSON';
  name = 'Angular';

  students: Student[] = studentsData;
  reservations: Reservation[] = reservationData;

}
